package prova03;
//jessica melo
public class Teste {

	public static void main(String[] args) {
		
		
		Plano umPlano = new Plano("Boa vida", 2020, 2);
		//Paciente umPaciente = new Paciente(umPlano, 1, "Mateus");
		
		 //Consulta umaconsulta = new Consulta(123, "Jo�o", "Arthur", "22/02/2020", 250.0);

	}

}
