package trabalhoPolimorfismo;

public class Personagem {

}
