package trabalhoPolimorfismo;

public class Vilao {

}
