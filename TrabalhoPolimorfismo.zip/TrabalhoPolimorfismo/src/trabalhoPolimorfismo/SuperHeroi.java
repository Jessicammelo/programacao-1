package trabalhoPolimorfismo;

public class SuperHeroi {

}
