package trabalhoPolimorfismo;

public class SuperPoder {

}
