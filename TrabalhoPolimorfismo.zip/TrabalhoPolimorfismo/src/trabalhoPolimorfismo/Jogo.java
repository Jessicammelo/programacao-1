package trabalhoPolimorfismo;

public class Jogo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
