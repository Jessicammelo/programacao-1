package Prova02;

public class Funcionario {

	private int codigo,quantFilhos;
	private String nome;
	private double horasExtras;
	private boolean fluenciaIdioma;
	
	public Funcionario(int codigo, int quantFilhos, String nome, double horasExtras, boolean fluenciaIdioma) {
		setCodigo(codigo);
		setQuantFilhos(quantFilhos);
		setNome(nome);
		setHorasExtras(horasExtras);
		setFluenciaIdioma(fluenciaIdioma);
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getQuantFilhos() {
		return quantFilhos;
	}

	public void setQuantFilhos(int quantFilhos) {
		this.quantFilhos = quantFilhos;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getHorasExtras() {
		return horasExtras;
	}

	public void setHorasExtras(double horasExtras) {
		this.horasExtras = horasExtras;
	}

	public boolean isFluenciaIdioma() {
		return fluenciaIdioma;
	}

	public void setFluenciaIdioma(boolean fluenciaIdioma) {
		this.fluenciaIdioma = fluenciaIdioma;
	}
	
	
}
