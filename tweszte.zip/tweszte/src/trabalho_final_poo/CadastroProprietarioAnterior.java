package trabalho_final_poo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class CadastroProprietarioAnterior extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CadastroProprietarioAnterior frame = new CadastroProprietarioAnterior();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public CadastroProprietarioAnterior() {
        setTitle("Cadastro de pessoa f\u00EDsica");
        setBounds(100, 100, 386, 204);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(10, 11, 62, 14);
        contentPane.add(lblNome);
        
        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setBounds(10, 37, 62, 14);
        contentPane.add(lblCpf);
        
        JLabel lblTelefone = new JLabel("Telefone:");
        lblTelefone.setBounds(10, 65, 62, 14);
        contentPane.add(lblTelefone);
        
        textField = new JTextField();
        textField.setBounds(101, 7, 86, 20);
        contentPane.add(textField);
        textField.setColumns(10);
        
        textField_1 = new JTextField();
        textField_1.setBounds(101, 33, 86, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);
        
        textField_2 = new JTextField();
        textField_2.setBounds(101, 61, 86, 20);
        contentPane.add(textField_2);
        textField_2.setColumns(10);
        
        JButton btnCancelar = new JButton("Cancelar");
        
        btnCancelar.setBounds(87, 124, 89, 23);
        contentPane.add(btnCancelar);
        
        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpar();
            }
        });
        btnLimpar.setBounds(177, 124, 89, 23);
        contentPane.add(btnLimpar);
        
        JButton btnOk = new JButton("OK");
        btnOk.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ProprietarioAnterior proprietarioAnterior = new ProprietarioAnterior();
                proprietarioAnterior.setNome(textField.getText());
                proprietarioAnterior.setCpf(textField_1.getText());
                proprietarioAnterior.setTelefone(textField_2.getText());
                proprietarioAnterior.setNacionalidade(textField_3.getText());
                Apresentacao.pessoas.add(proprietarioAnterior);
                limpar();
            }
        });
        btnOk.setBounds(267, 124, 89, 23);
        contentPane.add(btnOk);
        
        JLabel lblNewLabel = new JLabel("Nacionalidade");
        lblNewLabel.setBounds(10, 92, 79, 16);
        contentPane.add(lblNewLabel);
        
        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(101, 88, 86, 20);
        contentPane.add(textField_3);
    }

    public void limpar() {
        textField.setText("");
        textField_1.setText("");
        textField_2.setText("");
        textField_3.setText("");
    }
}
