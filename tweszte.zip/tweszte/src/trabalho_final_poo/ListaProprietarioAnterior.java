package trabalho_final_poo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;
import java.awt.event.ActionEvent;
import javax.swing.JTable;

public class ListaProprietarioAnterior extends JFrame {

    private static final long serialVersionUID = 1L;
    private List<Pessoa> pessoas;
    private JPanel contentPane;
	private JTable table;
	private DefaultTableModel tableModel;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListaProprietarioAnterior frame = new ListaProprietarioAnterior();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListaProprietarioAnterior() {
		setTitle("Cadastro de Propriet\u00E1rio Anterior");
		setBounds(100, 100, 533, 367);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		pessoas = Apresentacao.pessoas.stream().filter(pessoa -> pessoa instanceof ProprietarioAnterior).collect(Collectors.toList());
        
		tableModel = new DefaultTableModel();
		tableModel.addColumn("Nome");
        tableModel.addColumn("CPF");
        tableModel.addColumn("Telefone");
        tableModel.addColumn("Nascionalidade");
        
		table = new JTable(tableModel);
		for(Pessoa p : pessoas) {
		    ProprietarioAnterior pold = (ProprietarioAnterior) p;
		    tableModel.addRow(new Object[]{pold.getNome(), pold.getCpf(), pold.getTelefone(), pold.getNacionalidade()});
        }
		table.setBounds(12, 101, 491, 167);
		contentPane.add(table);
		
		JButton btnNewButton = new JButton("Fechar");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        dispose();
		    }
		});
		btnNewButton.setBounds(406, 281, 97, 25);
		contentPane.add(btnNewButton);
		
		lblNewLabel = new JLabel("Selecione o Propriet\u00E1rio anterior");
		lblNewLabel.setBounds(12, 13, 205, 16);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(210, 13, 293, 22);
		contentPane.add(comboBox);
		
		JButton btnNewButton_1 = new JButton("Vincular");
		btnNewButton_1.setBounds(406, 48, 97, 25);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Criar novo propriet\u00E1rio");
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        new CadastroProprietarioAnterior().setVisible(true);
		    }
		});
		btnNewButton_2.setBounds(206, 48, 188, 25);
		contentPane.add(btnNewButton_2);
	}
}
