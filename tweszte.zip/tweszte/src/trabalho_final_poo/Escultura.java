package trabalho_final_poo;

public class Escultura extends ObraDeArte {
	private String estilo;
	private String material;
	
	public Escultura() {
	}

	public String getEstilo() {
		return estilo;
	}

	public void setEstilo(String estilo) {
		this.estilo = estilo;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}
}
