package trabalho_final_poo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ListaObras extends JFrame {
    private static final long serialVersionUID = 1L;
    private JFrame frame;
    private JTable table;
    private List<ObraDeArte> obras = new ArrayList<ObraDeArte>();
    DefaultTableModel tableModel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    ListaObras window = new ListaObras(null, null);
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public ListaObras(Autor autor, ProprietarioAnterior proprietarioAnterior) {
        initialize();
        for (Entry<String, ObraDeArte> entry : Apresentacao.acervo.entrySet()) {
            if (entry.getValue().getAutor().equals(autor)) {
                obras.add(entry.getValue());
                continue;
            }
            for(ProprietarioAnterior p : entry.getValue().getProps()) {
                if (p.equals(proprietarioAnterior)) {
                    obras.add(entry.getValue());
                    break;
                }
            }
        }
        int index = 0;
        for(ObraDeArte o : obras) {
            tableModel.insertRow(index, new Object[] { o.getTitulo(), o.getAutor().getNome(), o.getAno(), "teste"});
            index++;
        }
    }
    
    public ListaObras() {
        initialize();
        for (Entry<String, ObraDeArte> entry : Apresentacao.acervo.entrySet()) {
            obras.add(entry.getValue());
        }
        int index = 0;
        for(ObraDeArte o : obras) {
            tableModel.insertRow(index, new Object[] { o.getTitulo(), o.getAutor().getNome(), o.getAno(), "teste"});
            index++;
        }
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setBounds(100, 100, 700, 548);
        getContentPane().setLayout(null);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("titulo");
        tableModel.addColumn("Autor");
        tableModel.addColumn("Ano");
        tableModel.addColumn("Tipo");
        
        table = new JTable(tableModel);
        table.setBounds(12, 13, 651, 438);
        getContentPane().add(table);

        JButton btnNewButton = new JButton("Fechar");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        btnNewButton.setBounds(566, 464, 97, 25);
        getContentPane().add(btnNewButton);

        JButton btnNewButton_1 = new JButton("remover");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int index = table.getSelectedRow();
                if (index > -1) {
                    ObraDeArte o = obras.get(index);
                    Apresentacao.acervo.remove(o.getTitulo());
                    dispose();
                }
            }
        });
        btnNewButton_1.setBounds(457, 464, 97, 25);
        getContentPane().add(btnNewButton_1);
    }
}
