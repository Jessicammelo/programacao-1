package trabalho_final_poo;

import java.util.ArrayList;

public class ProprietarioAnterior extends PessoaFisica {
	private String nacionalidade;
	private ArrayList<ObraDeArte> obras = new ArrayList<>();
	
	public ProprietarioAnterior() {
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

	public ArrayList<ObraDeArte> getObras() {
		return obras;
	}

	public void setObras(ArrayList<ObraDeArte> obras) {
		this.obras = obras;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((nacionalidade == null) ? 0 : nacionalidade.hashCode());
        result = prime * result + ((obras == null) ? 0 : obras.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        return this.getNome().equals(((Pessoa) obj).getNome());
    }
	
	

}
