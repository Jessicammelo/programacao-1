package trabalho_final_poo;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.stream.Collectors;
import java.awt.event.ActionEvent;
import java.awt.Choice;
import java.awt.Button;

import javax.management.RuntimeErrorException;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class CadastroObra extends JFrame {

    private List<Pessoa> autor;
    private List<Pessoa> proprietarioAntigo;

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField6;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField5;
    private JTextField textField7;
    private JTextField textField11;
    private JTextField textField9;
    private JTextField textField8;
    private JTextField textField10;

    private DefaultTableModel tableModel;

    private ObraDeArte obraDeArte = null;
    private JTable table;
    private JTextField textField_1;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    CadastroObra frame = new CadastroObra();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public CadastroObra() {
        setTitle("Cadastro de Obra de Arte");
        setBounds(100, 100, 532, 810);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("T\u00EDtulo:");
        lblNewLabel.setBounds(10, 24, 95, 14);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(115, 18, 248, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblAno = new JLabel("Ano de cria\u00E7\u00E3o:");
        lblAno.setBounds(239, 230, 101, 14);
        contentPane.add(lblAno);

        textField6 = new JTextField();
        textField6.setBounds(343, 224, 86, 20);
        contentPane.add(textField6);
        textField6.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Valor:");
        lblNewLabel_1.setBounds(10, 202, 81, 14);
        contentPane.add(lblNewLabel_1);

        textField3 = new JTextField();
        textField3.setBounds(115, 196, 86, 20);
        contentPane.add(textField3);
        textField3.setColumns(10);

        JLabel lblDataDeCriao = new JLabel("Data de cria\u00E7\u00E3o:");
        lblDataDeCriao.setBounds(239, 202, 101, 14);
        contentPane.add(lblDataDeCriao);

        textField4 = new JTextField();
        textField4.setBounds(343, 196, 86, 20);
        contentPane.add(textField4);
        textField4.setColumns(10);

        JLabel lblPathDaImagem = new JLabel("Path da imagem:");
        lblPathDaImagem.setBounds(12, 55, 108, 14);
        contentPane.add(lblPathDaImagem);

        textField1 = new JTextField();
        textField1.setBounds(115, 52, 248, 20);
        contentPane.add(textField1);
        textField1.setColumns(10);

        JLabel lblAutor = new JLabel("Autor:");
        lblAutor.setBounds(10, 177, 70, 14);
        contentPane.add(lblAutor);

        JLabel lblObservaes = new JLabel("Observa\u00E7\u00F5es:");
        lblObservaes.setBounds(10, 86, 95, 14);
        contentPane.add(lblObservaes);

        textField2 = new JTextField();
        textField2.setBounds(115, 86, 248, 45);
        contentPane.add(textField2);
        textField2.setColumns(10);

        JComboBox comboBox = new JComboBox(new Object[] { "Escultura", "Tapete", "Quadro" });
        comboBox.addItemListener(new ItemListener() {

            public void itemStateChanged(ItemEvent e) {
                if (comboBox.getSelectedItem() == "Escultura") {
                    //desabilitar campos aqui
                }
                System.out.println(comboBox.getSelectedItem());
            }
        });

        comboBox.setBounds(115, 140, 101, 20);
        contentPane.add(comboBox);

        JLabel lblTipoDaObra = new JLabel("Tipo da obra:");
        lblTipoDaObra.setBounds(10, 146, 95, 14);
        contentPane.add(lblTipoDaObra);

        JLabel lblEstilo = new JLabel("Estilo:");
        lblEstilo.setBounds(10, 230, 81, 14);
        contentPane.add(lblEstilo);

        textField5 = new JTextField();
        textField5.setBounds(115, 224, 86, 20);
        contentPane.add(textField5);
        textField5.setColumns(10);

        JLabel lblMaterial = new JLabel("Material:");
        lblMaterial.setBounds(10, 259, 77, 14);
        contentPane.add(lblMaterial);

        textField7 = new JTextField();
        textField7.setBounds(115, 253, 86, 20);
        contentPane.add(textField7);
        textField7.setColumns(10);

        textField11 = new JTextField();
        textField11.setBounds(343, 303, 86, 20);
        contentPane.add(textField11);
        textField11.setColumns(10);

        JLabel lblPas = new JLabel("Pa\u00EDs:");
        lblPas.setBounds(239, 309, 101, 14);
        contentPane.add(lblPas);

        JLabel lblTcnica = new JLabel("T\u00E9cnica:");
        lblTcnica.setBounds(10, 284, 86, 14);
        contentPane.add(lblTcnica);

        textField9 = new JTextField();
        textField9.setBounds(115, 278, 86, 20);
        contentPane.add(textField9);
        textField9.setColumns(10);

        JLabel lblLargura = new JLabel("Largura:");
        lblLargura.setBounds(239, 259, 101, 14);
        contentPane.add(lblLargura);

        textField8 = new JTextField();
        textField8.setBounds(343, 253, 86, 20);
        contentPane.add(textField8);
        textField8.setColumns(10);

        JLabel lblComprimento = new JLabel("Comprimento:");
        lblComprimento.setBounds(239, 284, 101, 14);
        contentPane.add(lblComprimento);

        textField10 = new JTextField();
        textField10.setBounds(343, 278, 86, 20);
        contentPane.add(textField10);
        textField10.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Propriet\u00E1rios Anteriores:");
        lblNewLabel_2.setBounds(12, 339, 153, 14);
        contentPane.add(lblNewLabel_2);

        Button button = new Button("Limpar");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                limpar();
            }
        });
        button.setBounds(336, 731, 81, 22);
        contentPane.add(button);

        Button button_1 = new Button("OK");

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        btnCancelar.setBounds(239, 731, 91, 23);
        contentPane.add(btnCancelar);

        JLabel lblNewLabel_3 = new JLabel("");
        lblNewLabel_3.setBounds(433, 284, 36, 14);
        contentPane.add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("");
        lblNewLabel_4.setBounds(433, 259, 46, 14);
        contentPane.add(lblNewLabel_4);

        autor = Apresentacao.pessoas.stream().filter(pessoa -> pessoa instanceof Autor).collect(Collectors.toList());
        String[] array = new String[autor.size()];
        for (int i = 0; i < array.length; i++) {
            array[i] = autor.get(i).getNome();
        }
        JComboBox comboBox_1 = new JComboBox(array);
        comboBox_1.setBounds(115, 174, 314, 20);
        contentPane.add(comboBox_1);

        JLabel lblNewLabel_5 = new JLabel("Selecione o Propriet\u00E1rio anterior");
        lblNewLabel_5.setBounds(10, 366, 205, 16);
        contentPane.add(lblNewLabel_5);

        proprietarioAntigo = Apresentacao.pessoas.stream().filter(pessoa -> pessoa instanceof ProprietarioAnterior).collect(Collectors.toList());
        array = new String[proprietarioAntigo.size()];
        for (int i = 0; i < array.length; i++) {
            array[i] = proprietarioAntigo.get(i).getNome();
        }
        JComboBox comboBox_2 = new JComboBox(array);
        comboBox_2.setBounds(208, 366, 293, 22);
        contentPane.add(comboBox_2);

        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        tableModel.addColumn("Nome");
        tableModel.addColumn("CPF");
        tableModel.addColumn("Telefone");
        tableModel.addColumn("Nacionalidade");
        table.setBounds(10, 454, 491, 167);
        contentPane.add(table);

        JButton btnNewButton_1 = new JButton("Vincular");
        btnNewButton_1.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                int index = comboBox_2.getSelectedIndex();
                ProprietarioAnterior p = (ProprietarioAnterior) proprietarioAntigo.get(index);
                tableModel.insertRow(0, new Object[] { p.getNome(), p.getCpf(), p.getTelefone(), p.getNacionalidade() });
            }
        });
        btnNewButton_1.setBounds(404, 401, 97, 25);
        contentPane.add(btnNewButton_1);

        JButton btnNewButton = new JButton("Remover proprietario");
        btnNewButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (table.getSelectedRow() > -1) {
                    int index = table.getSelectedRow();
                    tableModel.removeRow(index);
                }
            }
        });
        btnNewButton.setBounds(296, 634, 205, 25);
        contentPane.add(btnNewButton);

        JButton btnNewButton_2 = new JButton("Consultar obras");
        btnNewButton_2.setBounds(161, 634, 127, 25);
        contentPane.add(btnNewButton_2);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(115, 302, 86, 20);
        contentPane.add(textField_1);

        button_1.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if (comboBox.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "Selecione um tipo de obra");
                }
                ObraDeArte obra = null;
                if (comboBox.getSelectedItem() == "Escultura") {
                    obra = new Escultura();
                    ((Escultura) obra).setEstilo(textField5.getText());
                    ((Escultura) obra).setMaterial(textField7.getText());
                } else if (comboBox.getSelectedItem() == "Tapete") {
                    obra = new Tapete();
                    ((Tapete) obra).setComprimento(Float.parseFloat(textField10.getText()));
                    ((Tapete) obra).setLargura(Float.parseFloat(textField8.getText()));
                    ((Tapete) obra).setTecnica(textField9.getText());
                    ((Tapete) obra).setPais(textField11.getText());
                } else if (comboBox.getSelectedItem() == "Tapete") {
                    obra = new Quadro();
                    ((Quadro) obra).setLargura(Integer.parseInt(textField8.getText()));
                    ((Quadro) obra).setTecnica(textField9.getText());
                    ((Quadro) obra).setEstilo(textField5.getText());
                    ((Quadro) obra).setAltura(Integer.parseInt(textField_1.getText()));
                } else {
                    throw new RuntimeErrorException(null, "Tipo inv�lido");
                }
                obra.setTitulo(textField.getText());
                obra.setAno(Integer.parseInt(textField6.getText()));
                obra.setValor(Float.parseFloat(textField3.getText()));
                obra.setAutor((Autor) autor.get(comboBox_1.getSelectedIndex()));
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    String nome = (String) tableModel.getValueAt(i, 0);
                    for (Pessoa p : proprietarioAntigo) {
                        if (p.getNome().equals(nome)) {
                            obra.getProps().add((ProprietarioAnterior) p);
                            for (Pessoa ps : Apresentacao.pessoas) {
                                if (ps instanceof ProprietarioAnterior) {
                                    if (ps.getNome().equals(p.getNome())) {
                                        ((ProprietarioAnterior) ps).getObras().add(obra);
                                    }
                                }
                            }
                        }
                    }
                }
                Apresentacao.acervo.put(textField.getText(), obra);
                limpar();
            }
        });
        button_1.setBounds(423, 731, 81, 22);
        contentPane.add(button_1);

        JLabel lblNewLabel_6 = new JLabel("Altura");
        lblNewLabel_6.setBounds(10, 308, 56, 16);
        contentPane.add(lblNewLabel_6);

    }

    public ObraDeArte getObraDeArte() {
        return this.obraDeArte;
    }

    public void limpar() {
        textField.setText("");
        textField1.setText("");
        textField2.setText("");
        textField3.setText("");
        textField4.setText("");
        textField5.setText("");
        textField6.setText("");
        textField7.setText("");
        textField8.setText("");
        textField9.setText("");
        textField10.setText("");
        textField11.setText("");
        textField_1.setText("");
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.removeRow(i);
        }
    }
}
