package trabalho_final_poo;

public class Autor extends Pessoa {
	private String nacionalidade;
	
	public Autor() {
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((nacionalidade == null) ? 0 : nacionalidade.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        return this.getNome().equals(((Pessoa) obj).getNome());
    }

	
}
