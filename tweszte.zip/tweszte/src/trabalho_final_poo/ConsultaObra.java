package trabalho_final_poo;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConsultaObra extends JFrame {

    private List<Pessoa> autor;
    private List<Pessoa> proprietarioAntigo;

    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    ConsultaObra frame = new ConsultaObra();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public ConsultaObra() {
        setTitle("Filtro de Obras de Arte");
        setBounds(100, 100, 415, 178);
        contentPane = new JPanel();
        contentPane.setToolTipText("");
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Autor:");
        lblNewLabel.setBounds(10, 17, 77, 14);
        contentPane.add(lblNewLabel);

        JLabel lblProprietrioAnterior = new JLabel("Propriet\u00E1rio Anterior:");
        lblProprietrioAnterior.setBounds(10, 46, 139, 14);
        contentPane.add(lblProprietrioAnterior);

        autor = Apresentacao.pessoas.stream().filter(pessoa -> pessoa instanceof Autor).collect(Collectors.toList());
        String[] array = new String[autor.size()];
        for (int i = 0; i < array.length; i++) {
            array[i] = autor.get(i).getNome();
        }

        JComboBox comboBox = new JComboBox(array);
        comboBox.setBounds(158, 13, 227, 22);
        contentPane.add(comboBox);

        proprietarioAntigo = Apresentacao.pessoas.stream().filter(pessoa -> pessoa instanceof ProprietarioAnterior).collect(Collectors.toList());
        array = new String[proprietarioAntigo.size()];
        for (int i = 0; i < array.length; i++) {
            array[i] = proprietarioAntigo.get(i).getNome();
        }
        JComboBox comboBox_1 = new JComboBox(array);
        comboBox_1.setBounds(161, 42, 224, 22);
        contentPane.add(comboBox_1);

        JButton btnPesquisar = new JButton("Pesquisar");
        btnPesquisar.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                ListaObras listaObras = new ListaObras((Autor) autor.get(comboBox.getSelectedIndex()), (ProprietarioAnterior) proprietarioAntigo.get(comboBox_1.getSelectedIndex()));
                listaObras.setVisible(true);
            }
        });
        btnPesquisar.setBounds(297, 95, 95, 23);
        contentPane.add(btnPesquisar);
    }
}
