package Prova03;

public class Entidade {

	private String nome;
	private String cnpj;	

}
