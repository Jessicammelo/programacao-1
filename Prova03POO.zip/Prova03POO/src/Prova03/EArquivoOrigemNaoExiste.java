package Prova03;

import java.io.IOException;

public class EArquivoOrigemNaoExiste extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
