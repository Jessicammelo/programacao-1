package Prova03;

import java.time.LocalDate;
import java.time.LocalTime;

public class EventoLive {

	private String url;
	
	public EventoLive(String titulo, LocalDate data, LocalTime horaInicio) {

	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
