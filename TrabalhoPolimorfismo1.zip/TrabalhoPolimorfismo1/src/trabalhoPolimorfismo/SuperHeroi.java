package trabalhoPolimorfismo;
//J�ssica Melo
import java.util.ArrayList;

public class SuperHeroi extends Personagem{

	public SuperHeroi(ArrayList<SuperPoder> superPoder, String nome, String nomeVidaReal) {
		super(superPoder, nome, nomeVidaReal);
		
	}
	 
}
